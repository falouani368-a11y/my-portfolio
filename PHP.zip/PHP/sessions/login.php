<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Connexion</title>
</head>
<body>

<h1>Connexion utilisateur</h1>

<form action="login_post.php" method="POST">

    <label>Login :</label>
    <input type="text" name="login" required>

    <br><br>

    <label>Mot de passe :</label>
    <input type="password" name="mdp" required>

    <br><br>

    <input type="submit" value="Connexion">

</form>

</body>
</html>
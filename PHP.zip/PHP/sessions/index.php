<?php

session_start();

/*
Vérifie si l'utilisateur est connecté
*/
if(!isset($_SESSION['login'])) {

    header("Location: login.php");
    exit();
}

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Accueil</title>
</head>
<body>

<h1>Bienvenue</h1>

<p>
Bonjour
<?php
echo $_SESSION['prenom'] . " " . $_SESSION['nom'];
?>
</p>

<p>
Votre login est :
<?php
echo $_SESSION['login'];
?>
</p>

<a href="logout.php">Déconnexion</a>

</body>
</html>
<?php

session_start();

require "connexion.php";

/*
Vérifie que les champs existent
*/
if(isset($_POST['login']) && isset($_POST['mdp'])) {

    $login = $_POST['login'];
    $mdp = $_POST['mdp'];

    /*
    Requête SQL
    */
    $sql = "SELECT * FROM util WHERE LoginUtil = ?";

    $requete = $pdo->prepare($sql);

    $requete->execute([$login]);

    $utilisateur = $requete->fetch();

    /*
    Vérification utilisateur
    */
    if($utilisateur) {

        /*
        Vérification mot de passe
        */
        if($mdp == $utilisateur['PassUtil']) {

            /*
            Création des variables de session
            */
            $_SESSION['login'] = $utilisateur['LoginUtil'];

            $_SESSION['nom'] = $utilisateur['NomUtil'];

            $_SESSION['prenom'] = $utilisateur['PrenomUtil'];

            header("Location: index.php");
            exit();

        } else {

            echo "Mot de passe incorrect";
        }

    } else {

        echo "Login inconnu";
    }

} else {

    echo "Formulaire incomplet";
}
?>
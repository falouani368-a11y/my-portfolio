<?php
// 🔌 Connexion à la base de données

$host = "localhost";
$dbname = "personnel";
$user = "root";
$password = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $password);

    // Active les erreurs pour debug
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $e) {
    die("Erreur connexion : " . $e->getMessage());
}


// 📥 Je récupère le service choisi

if (isset($_GET['service'])) {
    $service = $_GET['service'];
} else {
    die("Aucun service sélectionné");
}


// 🔎 Je récupère le nom du service (ex: Commercial)

$sqlService = "SELECT DesiServ FROM service WHERE CodeServ = :code";
$stmtService = $pdo->prepare($sqlService);
$stmtService->execute(['code' => $service]);

$nomService = $stmtService->fetchColumn();


// 🔎 Requête pour récupérer les employés du service

$sql = "SELECT Matricule, NomEmpl, PrenomEmpl 
        FROM employe 
        WHERE ServEmpl = :service";

$stmt = $pdo->prepare($sql);
$stmt->execute(['service' => $service]);

$employes = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Liste des employés</title>
</head>
<body>

<h1>
    Liste des employés du service 
    <?php echo htmlspecialchars($nomService); ?>
</h1>

<table border="1">
    <tr>
        <th>Matricule</th>
        <th>Nom</th>
        <th>Prénom</th>
    </tr>

    <?php
    //  J'affiche chaque employé
    foreach ($employes as $emp) {
        echo "<tr>";
        echo "<td>" . $emp['Matricule'] . "</td>";
        echo "<td>" . $emp['NomEmpl'] . "</td>";
        echo "<td>" . $emp['PrenomEmpl'] . "</td>";
        echo "</tr>";
    }
    ?>

</table>

</body>
</html>
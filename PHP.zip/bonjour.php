<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Bonjour</title>
</head>
<body>

<form action="reponse.php" method="post">
    <label>Entrez votre prénom :</label>
    <input type="text" name="prenom" required>

    <br><br>

    <input type="submit" value="Dire bonjour">
</form>

</body>
</html>
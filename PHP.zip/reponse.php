<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Réponse</title>
</head>
<body>

<?php
$prenom = $_POST['prenom'];
echo "Bonjour " . htmlspecialchars($prenom) . " !";
?>

</body>
</html>
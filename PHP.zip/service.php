<?php
// Cette page affiche un formulaire pour choisir un service
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Choix du service</title>
</head>
<body>

<h1>Choix d'un service</h1>

<!-- 
    J'envoie le service sélectionné vers employesService.php
-->
<form action="employeservice.php" method="get">

    <label>Service :</label>

    <!-- 
        Ici je mets les codes des services (s01, s02, ...)
        car c'est ce qui est stocké dans la base
    -->
    <select name="service">
        <option value="s01">Fabrication</option>
        <option value="s02">Emballage</option>
        <option value="s03">Commercial</option>
        <option value="s04">Administration</option>
    </select>

    <br><br>

    <!-- Bouton d'envoi -->
    <input type="submit" value="Afficher les employés">

</form>

</body>
</html>